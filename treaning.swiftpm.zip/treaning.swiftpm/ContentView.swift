import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
                .background(Color.blue)
            Text("Hello, swift!")
        };
        statusBar(hidden: false)
    }
}
